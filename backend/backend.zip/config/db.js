import mongoose from "mongoose";

let isConnected = false;

export async function connectDB() {
    if (isConnected) return;

    await mongoose.connect(process.env.MONGO_URI, {
        maxPoolSize: 10,
    });

    isConnected = true;
    console.log("✅ MongoDB connected");
}
